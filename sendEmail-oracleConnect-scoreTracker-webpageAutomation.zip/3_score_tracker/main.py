#######################
# Score Tracker 1.2
# 2020-11-20
# by Will Avery
#######################
import shutil
import os
import sys

players=["Kola","Ben","Mark","Karl","Ken","Norman","Rachel","Mario","Tabitha","David"]
points=[0,0,0,0,0,0,0,0,0,0]
index,iscurrent,name,score=0,0,"",0
exit_condition=["QUIT","EXIT","END","Q"]

def game_intro():
  print('\x1bc') #Clear screen
  print('Welcome to Python Score Tracker')
  print('Enter name & number to keep score')
  print('To add a name type "append new_player_name"')
  print('To remove a name type "remove the_player_name"')
  print('To exit type "quit" for name')
  print('To save score type "save filename.py"')
  print('To load score type "import filename"')
  print('---------------------------------')    


while name.upper()!="QUIT":
  game_intro()
  for player,point in zip(players,points):
    if name.upper()==player.upper():
      try:
        points[index]+=int(score)
      except ValueError:
        points[index]+=0
      iscurrent=points[index]
      print(f'{player} has {iscurrent} points') 
    elif name.upper()=="EVERYBODY":
      try:
        points[index]+=int(score)
        iscurrent=points[index]
        print(f'{player} has {str(iscurrent)} points') 
      except:
        print("invalid score input")
    elif name.upper()=="RESET ALL":
      try:
        points[index]=int(score)
        iscurrent=points[index]
        print(f'{player} has {iscurrent} points')    
      except:
        print("invalid score input")
    else:
      print(f'{player} has {point} points')
    index+=1
  index=0
  print('---------------------------------')
  name=input  ("Name : ")

  if name.upper()[:6]=="APPEND":
    players.append(name[7:])
    points.append(0)   
  elif name.upper()[:6]=="REMOVE":
    try:
      points.remove(points[players.index(name[7:])])
      players.remove(name[7:])     
    except:
      print("Name not in list")  
  elif name.upper()=='QUIT' or name.upper()=='EXIT' or name.upper()=='Q':
  #if any(exit_condition)==name.upper():
    break
  elif name.upper()[:4]=="SAVE":
    try:
      with open(name[5:],"x") as f:
        f.write ('players='+str(players)+'\n')
        f.write ('points='+str(points))
        print (f'Current scores saved as {name[5:]}')     
        print (players)
        print(points)
        input("press enter:")
    except FileExistsError:
        print ("File already exists")
        input("press enter:")

    # Python executable imports from user application
	# Copy the written file to user application path for default import with executable
    try: 
      shutil.copy(name[5:],sys.path[1])
      shutil.copy(name[5:],sys.path[0])
    except:
      print ('copy error')

  elif name.upper()[:6]=="IMPORT":
    try:
      temp1='from '+name[7:]+' import players'
      temp2='from '+name[7:]+' import points'
      print(temp1)
      print(temp2)
      exec (temp1)
      exec (temp2)
    except OSError as err:
      print("OS error: {0}".format(err))	  
    except:
      print("Unexpected error:", sys.exc_info())
      print(sys.path)
      print("import error")
      input("press enter:")
  else:
    score=input ("Score : ")      


