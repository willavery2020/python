#https://myaccount.google.com/lesssecureapps
#  Allow less secure apps: ON
# **Note: Setting can not be adjusted if using 2-Factor authentication
#Reference URLs on How to do
#  https://realpython.com/python-send-email/
#  https://www.youtube.com/watch?v=YPiHBtddefI

import smtplib, ssl, getpass

port = 587  # For starttls
smtp_server = "smtp.gmail.com"
sender_email = "willavery2012@gmail.com"
receiver_email = "willavery@hotmail.com"
print(f"from: {sender_email}")
password = getpass.getpass("Type your password and press enter:")
message = """\
Subject: Hi there

This message is sent from Python."""

context = ssl.create_default_context()
with smtplib.SMTP(smtp_server, port) as server:
    server.starttls(context=context)
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)