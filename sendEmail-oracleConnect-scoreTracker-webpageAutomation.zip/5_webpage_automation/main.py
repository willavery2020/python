#pip install Selenium
#
#Check your current browser version to download the correct version
#Search browser: "selenium web driver chrome download"
# https://chromedriver.chromium.org/downloads
# https://chromedriver.storage.googleapis.com/index.html?path=87.0.4280.20/
# YouTube Notes: https://www.youtube.com/watch?v=GJjMjB3rkJM
#####################
from selenium import webdriver
browser=webdriver.Chrome("C:\\python\\chromedriver_win32\\chromedriver.exe")
browser.get("https://www.yahoo.com/")
searchBar=browser.find_element_by_id("ybar-sbq")
searchBar.send_keys("ufc mma")
from selenium.webdriver.common.keys import Keys
searchBar.send_keys(Keys.ENTER)












C:\WINDOWS\system32>pip install Selenium
Collecting Selenium
  Downloading selenium-3.141.0-py2.py3-none-any.whl (904 kB)
     |████████████████████████████████| 904 kB 6.8 MB/s
Collecting urllib3
  Downloading urllib3-1.26.2-py2.py3-none-any.whl (136 kB)
     |████████████████████████████████| 136 kB 6.4 MB/s
Installing collected packages: urllib3, Selenium
Successfully installed Selenium-3.141.0 urllib3-1.26.2


