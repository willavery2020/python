#May have to install C++ VISUAL STUDIO LIBRARY before cx_Oracle and reboot
#     python -m pip install cx_Oracle --upgrade

import cx_Oracle, getpass

host_name="N10HDN-FYTQQ13.MicroPactCorp.com"
sid="will"
print(f"Test logging into Oracle Database - {host_name}")
user_name=input("Enter user name: ")
password=getpass.getpass("Enter user password: ")

connect_string=f"{user_name}/{password}@{host_name}:1521/{sid}"
#print(connect_string)
connection = cx_Oracle.connect(connect_string)
cur=connection.cursor()
cur.execute('select * from test')
for line in cur:
  print(line)
cur.close()
connection.close()
