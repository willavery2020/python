import sys
#pip3 install pyttsx3
#pyttsx3=2.90
import pyttsx3

#pip3 install pywhatkit
#pywhatkit=1.26.2
#import pywhatkit as kit

#pip3 install python-docx
#python-docx=0.8.10
from docx.shared import Inches
from docx import Document

str_temp=''

def Question(text):
    global str_temp
    print(text)
    pyttsx3.speak(text)
    str_temp=input()
    document.add_paragraph(text)
    document.add_paragraph(str_temp)
    
def Response(text):
    print(text)
    pyttsx3.speak(text)
    document.add_paragraph(text)


document=Document()
#document.add_picture('talk_to_myself2.jpg')
document.add_picture('C:\\temp\\talk_to_myself2.jpg')
Question('Hello. My name is Talk-2-Me Python. What\'s your name? ' )
Response('Nice to meet you '+str_temp+'.')
name=str_temp
Question('If you were a potato, how would you like to be cooked?')
Response(str_temp  +' is an interesting choice. I would pick Loaded Potato Soup with garlic toast on the side.')
food=str_temp
Question('What famous person or cartoon character do you look like?')
Response('Yes, I see the resemblance to '+str_temp+'. I was once mistaken for a Boa Constrictor, but Pythons are much cuter.')
lookalike=str_temp
Response('It was good chatting with you '+lookalike+'... I mean '+name+'. I have to run. Maybe we could eat '+food+' potato sometime.')
#\n Hope you enjoy the video, "Talk To Myself" by Christopher Williams.')

Response('\n\nOur conversation is save as file name: "saved_conversation_'+name+'.docx" ')

document.save('saved_conversation_'+name+'.docx')
k=input("wait...")


#kit.playonyt('Christopher Williams - Talk To Myself')
